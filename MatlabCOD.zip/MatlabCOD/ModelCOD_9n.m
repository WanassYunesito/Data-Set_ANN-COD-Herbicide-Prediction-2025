clear all;
close all;

	%lecture des fichiers
   load databasegeneral1.txt
   data = databasegeneral1'

   % Inputs (Features)
  T_v = data(1,:); % Reaction time
  pH_v = data(2,:); %pH
  CONCENTRATION_v = data(3,:); %Contaminant of concentartion
  CONTAMINANT_v = data(4,:); %Contaminant
  US_v = data(5,:); %Ultrasound
  UV_v = data(6,:); %Ultaviolet
  TIO_v = data(7,:); %Catalyst
  PRESULFAT_v = data(8,:); % Oxidize
  RS_v = data(9,:); % Radiation
  
    
  %Output (Labels)
  DQO_v=data(10,:)
  

%normalisation
T_norm = 0.8*((T_v - min(T_v))/(max(T_v) - min(T_v)))+0.1;
pH_norm = 0.8*((pH_v - min(pH_v))/(max(pH_v) - min(pH_v)))+0.1;
CONCENTRATION_norm = CONCENTRATION_v;
CONTAMINANT_norm = CONTAMINANT_v;
US_norm = 0.8*((US_v - min(US_v))/(max(US_v) - min(US_v)))+0.1;
UV_norm = 0.8*((UV_v - min(UV_v))/(max(UV_v) - min(UV_v)))+0.1;
TIO_norm = 0.8*((TIO_v - min(TIO_v))/(max(TIO_v) - min(TIO_v)))+0.1;
PRESULFAT_norm = 0.8*(( PRESULFAT_v - min( PRESULFAT_v))/(max( PRESULFAT_v) - min( PRESULFAT_v)))+0.1;
RS_norm = 0.8*((RS_v - min(RS_v))/(max(RS_v) - min(RS_v)))+0.1;


p=[T_norm;pH_norm;CONCENTRATION_norm;CONTAMINANT_norm;US_norm;UV_norm;TIO_norm;PRESULFAT_norm;RS_norm];

% Target
t=DQO_v;
% Tama�o de la base de datos de entrada
[R,Q]=size(p);

% Divison base de datos
iitst=3:4:Q;  
iival=3:4:Q; %Validation (20%); Q = 275
iitr=[1:4:Q 2:4:Q 4:4:Q]; %Training (80%)
val.P = p(:,iival);
val.T = t(:,iival);
test.P = p(:,iitst);
test.T = t(:,iitst);
ptr = p(:,iitr);
ttr = t(:,iitr);

n=0;
c=1
while c==1
    
net=newff(minmax(p),[9,1],{'tansig','purelin'},'trainlm');
net.trainParam.show= 50;
%net.trainParam.lr= 0.05;
net.trainParam.Epoch= 1000;
net.trainParam.goal= 1e-9;

[net,tr]=train(net,ptr,ttr,[],[],val,test);
an= sim(net,p);


[m,b,r]= postreg(an,t);
   r
    
if r > 0.99
    c=0;
    IW=net.IW{1,1};
    LW=net.LW{2,1};
    b1=net.b{1};
    b2=net.b{2};
    save IWyounessCOD_09n.txt IW -ascii;
    save LWyounessCOD_09n.txt LW -ascii;
    save b1younessCOD_09n.txt b1 -ascii;
    save b2younessCOD_09n.txt b2 -ascii;
    save regyounessCOD_09n.txt m b r -ascii;

else r <=  0.99
n=n+1
c=1;
end
if n >=2000000
      c=0;
end

end

figure(1)
    
plot(tr.epoch,tr.perf,tr.epoch,tr.vperf,tr.epoch,tr.tperf)
legend('training','validation','test',-1);
ylabel('squared Error');xlabel('Epoch')

figure(2)
[m,b,r]= postreg(an,t);% m=pendiente,b=intercepto,r=coeficiente de correlaci�n(r-cuadrada).